/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.listaexercicio1;
import java.util.Scanner;
/**
 *
 * @author João Ferrari
 */
public class Exercicio4 {
    
     public static void main(String[] args) {
         
         Scanner ler = new Scanner(System.in);
         String triangulo;
         
        System.out.print("lado  1: ");
        double lado1 = ler.nextDouble();

        System.out.print("lado 2: ");
        double lado2 = ler.nextDouble();

        System.out.print("lado 3: ");
        double lado3 = ler.nextDouble();

        

        if (lado1 == lado2 && lado2 == lado3) {
            System.out.print("Equilatero");
        } else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3) {
              System.out.print("isosles");
        } else {
              System.out.print("Escaleno");
        }

        //System.out.println("Triangulo: " + triangulo);

     
         
     }
    
}
