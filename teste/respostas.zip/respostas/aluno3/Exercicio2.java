/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.listaexercicio1;

/**
 *
 * @author João Ferrari
 */


public class Exercicio2 {
    public static void main(String[] args) {
        
      for (int num = 1; num <= 9; num++) {
            System.out.println("Tabuada do " + num);
            for (int multiplica = 1; multiplica <= 10; multiplica++) {
                System.out.printf("%d x %d = %d\n", num, multiplica, num * multiplica);
            }
            System.out.println(); 
    
}

    }
    
}
