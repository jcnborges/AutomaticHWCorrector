/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.listaexercicio1;

/**
 *
 * @author João Ferrari
 */
import java.util.Scanner;

public class Exercicio3 {
    
    public static void main(String[] args) {
        
        double[] nums =new double[10];
        Scanner leitura =new Scanner(System.in);
        //double num =leitura.nextDouble();
         double media=0.0;
         double soma=0.0;
         double menor=101;
         
        for(int i=0; i<nums.length;i++)
        {
            System.out.printf("Digite %d numeros:\n",i + 1);
            nums[i]=leitura.nextDouble();
            
        }
        for(int i =0; i<nums.length;i++)
        {
            soma+=nums[i];
            media =soma/nums.length;
        }
        double maior=0.0;
        
        for(int i=1;i<nums.length;i++)
        {
            if(nums[i]>maior)
            {
                maior=nums[i];
            }
        }
        
        for(int i=0;i<nums.length;i++)
        {
            if(nums[i]<menor)
            {
                menor=nums[i];
            }
        }
        
          
        System.out.println("Media calulo:"+ String.format("%.2f",media));
        System.out.println("Maior numero:"+ String.format("%.2f",maior)); 
        System.out.println("Menor numero:"+ String.format("%.2f",menor)); 
       
    }
    
}
