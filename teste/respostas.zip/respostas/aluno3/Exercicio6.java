/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.listaexercicio1;

/**
 *
 * @author João Ferrari
 */
import java.util.Scanner;

public class Exercicio6 {
    
      public static void main(String[] args) {
        
        Scanner ler = new Scanner(System.in);

        
        System.out.print("Digite seu nome: ");
        String nome = ler.nextLine();

       
        System.out.print("Digite seu endereço: ");
        String endereco = ler.nextLine();

        
        System.out.print("Digite seu telefone: ");
        String tel = ler.nextLine();

        
        System.out.print("Digite sua idade: ");
        int idade = ler.nextInt();

       
        System.out.println("nome é " + nome + ", você tem " + idade + " anos, mora no " + endereco + " e  é " + tel);

        
     }
    
}
