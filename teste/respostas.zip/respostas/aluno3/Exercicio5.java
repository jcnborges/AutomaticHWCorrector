/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.listaexercicio1;

/**
 *
 * @author João Ferrari
 */
import java.util.Random;
import java.util.Scanner;

public class Exercicio5 {
    
    public static void main(String[] args) {
        
        Random geradorAleatorio = new Random();
        Scanner ler = new Scanner(System.in);

        int numeroSecreto = geradorAleatorio.nextInt(100) + 1; 
        int palte;
        int tent = 0;

        System.out.println("Bem-vindo ao Jogo de Adivinhação!");

        do {
            tent++;
            System.out.print("Digite seu palpite (1-100): ");
            palte = ler.nextInt();

            if (palte < numeroSecreto) {
                System.out.println("Numeroinserido  baixo");
            } else if (palte > numeroSecreto) {
                System.out.println("numero inserido alto");
            }
        }while(palte != numeroSecreto);

        System.out.println("Voce acertou nuemro " + tent + " tentativas.");
    

        
    }
}
        
    
    

