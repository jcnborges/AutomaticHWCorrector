/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.listaexercicio1;

import java.util.Scanner;
import java.util.Locale;

/**
 *
 * @author João Ferrari
 */
public class Exercicio1 {
    
     public static void main(String[] args) {
         
    Locale.setDefault(Locale.US);
    Scanner leitura = new Scanner(System.in);
    double metros =leitura.nextDouble();
    
    double decimetros= metros *10;
            
    double centimetros= metros *100;
            
    double milimetros= metros*1000;
    
    System.out.println("Decimetros:\n"+ String.format("%.2f",decimetros));
    System.out.println("Decimetros:\n"+ String.format("%.2f",centimetros));
    System.out.println("Decimetros:\n"+ String.format("%.2f",milimetros));
    
    
    }
}
