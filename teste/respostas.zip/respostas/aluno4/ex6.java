import java.util.Scanner;

public class InformacoesPessoais {
	public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        System.out.print("Digite seu nome: ");
        String nome = scan.nextLine();
        
        System.out.print("Digite sua idade: ");
        int idade = scan.nextInt();
        scan.nextLine();
        
        System.out.print("Digite seu endereço: ");
        String endereco = scan.nextLine();
        
        System.out.print("Digite seu telefone: ");
        String telefone = scan.nextLine();
        
        System.out.println("Seu nome é " + nome + ", você tem " + idade + " anos, mora na rua " + endereco + " e seu telefone é " + telefone + ".");
        
        scan.close();
    }


}
