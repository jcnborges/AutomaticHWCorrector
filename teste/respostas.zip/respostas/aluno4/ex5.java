import java.util.Scanner;
import java.util.Random;
public class Adivinhacao {
	
	public static void main(String[] args) {
        Scanner valor = new Scanner(System.in);
        Random num = new Random();
        
        int numeroSorteado = num.nextInt(100) + 1;
        int palpite;
        int tentativas = 0;
        
        System.out.println("jogo de adivinhação");
        
        do {
            System.out.print("Digite seu palpite (de 1 a 100): ");
            palpite = valor.nextInt();
            tentativas++;
            
            if (palpite < numeroSorteado) {
                System.out.println("O número sorteado é maior.");
            } else if (palpite > numeroSorteado) {
                System.out.println("O número sorteado é menor.");
            } else {
                System.out.println("Parabéns você acertou o número sorteado em " + tentativas + " tentativas.");
            }
        } while (palpite != numeroSorteado);
        
        valor.close();
    }

}
