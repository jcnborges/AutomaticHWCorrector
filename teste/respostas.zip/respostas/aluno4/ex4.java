import java.util.Scanner;

public class Triangulos {
	public static void main(String[] args) {
        Scanner valor = new Scanner(System.in);
        
        System.out.println("Digite o comprimento dos três lados do triângulo:");
        double lad1 = valor.nextDouble();
        double lad2 = valor.nextDouble();
        double lad3 = valor.nextDouble();
        
            if (lad1 == lad2 && lad2 == lad3) {
                System.out.println("O triângulo é equilátero.");
            } else if (lad1 == lad2 || lad1 == lad3 || lad2 == lad3) {
                System.out.println("O triângulo é isósceles.");
            } else {
                System.out.println("O triângulo é escaleno.");
            }
        valor.close();
    }

}
