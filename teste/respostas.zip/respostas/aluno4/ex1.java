import java.util.Scanner;

public class ConversorMedidas {
	
	public static void main(String[] args) {
        Scanner valor = new Scanner(System.in);
        
        System.out.print("Digite um valor em metros: ");
        double metros = valor.nextDouble();
        
        double decimetros = metros * 10;
        double centimetros = metros * 100;
        double milimetros = metros * 1000;
        
        System.out.println(metros + " metros correspondem a:");
        System.out.println(decimetros + " decímetros");
        System.out.println(centimetros + " centímetros");
        System.out.println(milimetros + " milímetros");
        
        valor.close();
    }

}
