import java.util.Scanner;
import java.util.Random;

public class JoquemPo {
	
	 public static void main(String[] args) {
	        Scanner scan = new Scanner(System.in);
	        Random random = new Random();
	        
	        int rodadasJogadas = 0;
	        int vitoriasJogador = 0;
	        int vitoriasComputador = 0;
	        
	        System.out.println("Bem-vindo ao jogo Pedra, Papel e Tesoura");
	        
	        while (rodadasJogadas < 3 && vitoriasJogador < 2 && vitoriasComputador < 2) {
	            System.out.print("Escolha Pedra, Papel ou Tesoura (Digite 1 para Pedra, 2 para Papel ou 3 para Tesoura): ");
	            int escolhaJogador = scan.nextInt();
	            
	            int escolhaComputador = random.nextInt(3) + 1;
	            
	            switch (escolhaComputador) {
	                case 1:
	                    System.out.println("O computador escolheu Pedra.");
	                    break;
	                case 2:
	                    System.out.println("O computador escolheu Papel.");
	                    break;
	                case 3:
	                    System.out.println("O computador escolheu Tesoura.");
	                    break;
	            }
	            
	            if ((escolhaJogador == 1 && escolhaComputador == 3) ||
	                (escolhaJogador == 2 && escolhaComputador == 1) ||
	                (escolhaJogador == 3 && escolhaComputador == 2)) {
	                System.out.println("Você ganhou essa rodada");
	                vitoriasJogador++;
	            } else if (escolhaJogador == escolhaComputador) {
	                System.out.println("Empate nessa rodada");
	            } else {
	                System.out.println("Você perdeu essa rodada");
	                vitoriasComputador++;
	            }
	            
	            rodadasJogadas++;
	            System.out.println();
	        }
	        
	        if (vitoriasJogador > vitoriasComputador) {
	            System.out.println("Parabéns você venceu o jogo");
	        } else if (vitoriasJogador < vitoriasComputador) {
	            System.out.println("Você perdeu o jogo");
	        } else {
	            System.out.println("O jogo terminou em empate");
	        }
	        
	        scan.close();
	    }

}
