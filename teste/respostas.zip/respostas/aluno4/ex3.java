import java.util.Scanner;

public class MediaMaiorMenor {
	
	public static void main(String[] args) {
        Scanner valor = new Scanner(System.in);
        
        double[] nume = new double[10];
        
        for (int i = 0; i < 10; i++) {
            System.out.print("Digite o " + (i + 1) + "º número: ");
            nume[i] = valor.nextDouble();
        }
       
        double soma = 0;
        for (double num : nume) {
            soma += num;
        }
        double media = soma / 10;
        
        double maior = nume[0];
        double menor = nume[0];
        for (int i = 0; i < 10; i++) {
            if (nume[i] > maior) {
                maior = nume[i];
            }
            if (nume[i] < menor) {
                menor = nume[i];
            }
        }
        
        System.out.println("A média dos números é: " + media);
        System.out.println("O maior número é: " + maior);
        System.out.println("O menor número é: " + menor);
        
        valor.close();
    }

}
