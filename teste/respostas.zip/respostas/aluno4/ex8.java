import java.util.Random;
import java.util.Scanner;

public class JogoDados {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Random random = new Random();
        
        int pontosJogador = 0;
        int pontosComputador = 0;
        int rodada = 1;
        
        System.out.println("Bem-vindo ao jogo de dados contra o computador");
        
        while (pontosJogador < 6 && pontosComputador < 6) {
            System.out.println("Rodada " + rodada + ":");
            
            int dadoJogador1 = random.nextInt(6) + 1;
            int dadoJogador2 = random.nextInt(6) + 1;
            int somaJogador = dadoJogador1 + dadoJogador2;
            System.out.println("Você jogou os dados: " + dadoJogador1 + " e " + dadoJogador2 + ".");
            
            int dadoComputador1 = random.nextInt(6) + 1;
            int dadoComputador2 = random.nextInt(6) + 1;
            int somaComputador = dadoComputador1 + dadoComputador2;
            System.out.println("O computador jogou os dados: " + dadoComputador1 + " e " + dadoComputador2 + ".");
            
            if (somaJogador > somaComputador) {
                System.out.println("Você ganhou esta rodada");
                pontosJogador++;
            } else if (somaJogador < somaComputador) {
                System.out.println("Você perdeu esta rodada.");
                pontosComputador++;
            } else {
                System.out.println("Empate nesta rodada.");
            }
            
            rodada++;
            System.out.println();
        }
        
        if (pontosJogador > pontosComputador) {
            System.out.println("Parabéns você ganhou o jogo");
        } else if (pontosJogador < pontosComputador) {
            System.out.println("Você perdeu o jogo");
        } else {
            System.out.println("O jogo terminou em empate");
        }
        
        scan.close();
    }
}
