/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercício1_java;

import java.util.Scanner;

/**
 *
 * @author Eduardo
 */
public class Exercício1_Java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner conversor = new Scanner(System.in);
        
        System.out.println("Digite aqui um valor em metros");
        int numero = conversor.nextInt();
        int decimetros = numero*100; int centimetros = numero*1000; int milimetros = numero*100;
        
        System.out.println("O valor digitado vale em decimetros: " + decimetros);
        System.out.println("O valor digitado vale em centimetros: " + centimetros);
        System.out.println("O valor digitado vale em milimetros: " + milimetros);
    }
    
}
