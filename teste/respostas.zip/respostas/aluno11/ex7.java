/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercício7_java;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Eduardo
 */
public class Exercício7_Java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int dado1, dado2, dado1_PC, dado2_PC, resul, resul_PC, i = 0;
        char resposta = 0;
        Random gerador = new Random();
        Random gerador_PC = new Random();
        
        while (i < 5){
       
            while (resposta != 'S' && resposta != 's') {
               /* Como os numeros sao aleatórios, dependendo
               do momento em que eles são gerados, os resultados
               podem mudar caso eles forem gerados antes ou depois
                */
               System.out.println("Voce aceita continuar?");
               Scanner leitor = new Scanner(System.in);
               resposta = leitor.next().charAt(0); 
            }
            dado1 = gerador.nextInt(6) + 1;
            dado2 = gerador.nextInt(6) + 1;
            dado1_PC = gerador_PC.nextInt(6) + 1;
            dado2_PC = gerador_PC.nextInt(6) + 1;
            resul = dado1 + dado2; resul_PC = dado1_PC + dado2_PC;
            
            if (resul > resul_PC) {
                i += 1;
                System.out.println("Voce venceu a partida " + i + "!");
                System.out.println("A soma dos numeros dos dados sao:");
                System.out.println("Voce: " + resul + " PC: " + resul_PC);
            }
            else {
                System.out.println("Nao foi desta vez! Jogue denovo!");
                System.out.println("Voce: " + resul + " PC: " + resul_PC);
            }
            resposta = 0;
        }
    }
    
}
