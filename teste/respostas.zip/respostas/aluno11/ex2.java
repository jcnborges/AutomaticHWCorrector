/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercício2_java;

import java.util.Scanner;

/**
 *
 * @author Eduardo
 */
public class Exercício2_Java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Digite aqui um valor inteiro para a tabuada:");
        Scanner conversor = new Scanner(System.in);
        int numero = conversor.nextInt();
        System.out.println("");
        
        for (int i = 1; i <= 9; i++) {
            int multiplicador = i;
            int resultado = numero;
            System.out.println(numero + "X" + multiplicador + "=" + resultado);
        }
        System.out.println("");
        
    }
    
}
