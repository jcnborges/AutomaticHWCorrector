/**
 * F.U.P que implemente um jogo de jóquei pow (pedra, papel e tesoura) contra o
 * computador. O programa implementa um jogo do tipo "melhor de três".
 */
package avaliacao;

import java.util.Random;
import java.util.Scanner;

public class JoqueiPow {
	
    public static void main(String[] args) {
            Random sorteador = new Random();
            Scanner entrada = new Scanner(System.in);
	    int scoreJogador = 0;
            int scoreMaquina = 0;
                
            String[] jokenpo = new String[3];
                jokenpo[0] = "Pedra";
                jokenpo[1] = "Papel";
                jokenpo[2] = "Tesoura";                    
	        
	    System.out.println("Joquei Pow contra o computador!\n - Pedra vence tesoura\n - Tesoura vence papel\n - Papel vence pedra");
	        
	        do {
	            System.out.print("\nDigite sua escolha (Pedra, Papel ou Tesoura): ");
	            String jogadaJogador = entrada.nextLine();
	            String jogadaMaquina = jokenpo[sorteador.nextInt(3)];
                    
                    if (jogadaJogador.equalsIgnoreCase(jogadaMaquina)) {
                        System.out.print("Empate! Tente novamente.\n");
                    }
                    else {
                        switch (jogadaMaquina) {
                            case "Pedra":
                                System.out.print("O computador joga Pedra. ");

                                    if (jogadaJogador.equalsIgnoreCase("Papel")) {
                                        scoreJogador++;
                                            System.out.print("Ganhou!\nJogador " + scoreJogador + " x " + scoreMaquina + " Computador\n");
                                    }

                                    else if (jogadaJogador.equalsIgnoreCase("Tesoura")) {
                                        scoreMaquina++;
                                            System.out.print("Perdeu!\nJogador " + scoreJogador + " x " + scoreMaquina + " Computador\n");
                                    }
                            break;

                            case "Papel":
                                System.out.print("O computador joga Papel. ");

                                    if (jogadaJogador.equalsIgnoreCase("Pedra")) {
                                        scoreMaquina++;
                                            System.out.print("Perdeu!\nJogador " + scoreJogador + " x " + scoreMaquina + " Computador\n");
                                    }

                                    else if (jogadaJogador.equalsIgnoreCase("Tesoura")) {
                                        scoreJogador++;
                                            System.out.print("Ganhou!\nJogador " + scoreJogador + " x " + scoreMaquina + " Computador\n");
                                    }
                            break;

                            case "Tesoura":
                                System.out.print("O computador joga Tesoura. ");

                                    if (jogadaJogador.equalsIgnoreCase("Pedra")) {
                                        scoreJogador++;
                                        System.out.print("Ganhou!\nJogador " + scoreJogador + " x " + scoreMaquina + " Computador\n");
                                    }

                                    else if (jogadaJogador.equalsIgnoreCase("Papel")) {
                                        scoreMaquina++;
                                        System.out.print("Perdeu!\nJogador " + scoreJogador + " x " + scoreMaquina + " Computador\n");
                                    }
                            break;
                        }
                    }
	        } while (scoreJogador < 2 && scoreMaquina < 2);
	        
	    if (scoreJogador > scoreMaquina) {
	        System.out.println("\nParabens! Voce venceu.");
	    }
                
            else if (scoreJogador < scoreMaquina) {
	        System.out.println("\nMais sorte na proxima! Voce perdeu.");
	    }
    }
}