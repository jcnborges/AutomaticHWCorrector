/**
 * F.U.P que imprime uma tabela com a tabuada de 1 a 9
 */
package avaliacao;

public class Tabuada {
    
    public static void main(String[] args) {
        
        System.out.println("TABELA DE TABUADAS\n");
                
            for(int i = 1; i<10; i++) {
                System.out.println("=======================\n|\tTabuada do " + i + "\t|\n=======================");
                
                for (int j = 1; j<=10; j++) {
                    System.out.println("|\t" + i + " * " + j + " = " + i*j + "\t|");
                }
                
                System.out.println("=======================\n");
            }
    }
}
