/**
 * F.U.P que leia 10 números decimais e armazene-os em um vetor, 
 * (i) calcule a média dos números lidos, 
 * (ii) mostre o maior e o
 * (iii) menor número.
 */
package avaliacao;

import java.util.Scanner;

public class VetorDecimais {
    
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        float[] vetor = new float[10];
        float media = 0;
        float maior;
        float menor;
        
        System.out.println("ARMAZENAMENTO DE 10 NUMEROS DECIMAIS");
        
        for(int i = 0; i<10; i++) {
            System.out.print("Digite um numero: ");
            
            vetor[i] = entrada.nextFloat();
            media += vetor[i];
        }
        
        media /= 10;
        maior = vetor[0];
        menor = vetor[0];
        
        for(int i = 0; i<10; i++) {
            if (vetor[i] > maior) {
                maior = vetor[i];
            }
            
            if (vetor[i] < menor) {
                menor = vetor[i];
            }
        }
        
        System.out.println("RESULTADOS");
        System.out.println("Media dos numeros: " + media);
        System.out.println("Maior numero: " + maior);
        System.out.println("Menor numero: " + menor);   
    }
}
