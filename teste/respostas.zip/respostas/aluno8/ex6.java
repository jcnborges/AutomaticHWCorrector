/**
 * F.U.P que pergunta o nome, o endereço, o telefone e a idade de uma pessoa e
 * monta uma string com a seguinte frase: "Seu nome é ..., você tem ... anos, 
 * mora na rua... e seu telefone é ..."
 */
package avaliacao;

import java.util.Scanner;

public class StringFrase {
    
    public static void main (String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Qual e o seu nome?");
            String nome = entrada.nextLine();
        
        System.out.println("\nQual e o seu endereco?");
            String endereco = entrada.nextLine();
        
        System.out.println("\nQual e a sua idade?");
            String idade = entrada.nextLine();
        
        System.out.println("\nQual e o seu telefone?");
            String telefone = entrada.nextLine();
        
        //Frase solicitada pelo exercício
        System.out.println("Seu nome e " + nome + ", voce tem " + idade + " anos, mora na rua " + endereco + " e seu telefone e " + telefone);
    }
}
