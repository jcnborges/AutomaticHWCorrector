/**
 * Faça um programa em Java que pergunta um valor em metros e imprime o 
 * correspondente em decímetros, centímetros e milímetros
 */
package avaliacao;

import java.util.Scanner;

public class Medidas {
	
	public static void main(String[] args) {
                
            Scanner entrada = new Scanner(System.in);
        
            System.out.print("Digite um valor em metros para conversão: ");
            float metros = entrada.nextFloat();
            
            System.out.println("\n Valor em metros: " + metros );
            System.out.println("Equivale a: ");
            System.out.println(metros/0.1 + " decimetros\n" + metros/0.01 + " centimetros\n" + metros/0.001 + " milimetros");
    }
}
