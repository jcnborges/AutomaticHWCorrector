/**
 * F.U.P que simule um jogo de adivinhação. O programa inicializa sorteando um
 * número de 1 a 100. Depois, o usuário digita um palpite até acertar o número.
 * Para cada palpite, o programa indica se o número digitado é maior ou menor
 * que o número sorteado. No final, o programa mostra quantas tentativas o 
 * usuário precisou para acertar.
 */
package avaliacao;

import java.util.Random;
import java.util.Scanner;

public class Adivinhacao {
    
    public static void main(String[] args) {
        
        Random sorteador = new Random();
        Scanner entrada = new Scanner(System.in);
        int numSorteio = sorteador.nextInt(100) + 1;
        int palpite;
        int contTentativas = 0;
        
        System.out.print("Jogo de Adivinhacao: adivinhe numeros de 1 a 100\n");
        do {
            System.out.println("\nDigite seu palpite: ");
                palpite = entrada.nextInt();
                
                if (palpite > numSorteio) {
                    System.out.println ("Palpite maior que o numero sorteado.");
                }
                
                else if (palpite < numSorteio) {
                    System.out.println ("Palpite menor que o numero sorteado.");
                }
                
                contTentativas++;
        } while (palpite != numSorteio);
        
        System.out.println("\nParabens! \nVoce acertou o numero sorteado no seu palpite numero " + contTentativas);
    }
}
