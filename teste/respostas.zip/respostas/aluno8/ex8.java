/**
 * F.U.P que implemente um jogo de dois dados contra o computador. O jogador
 * avanças as rodadas caso a soma de seus dados seja maior que a do computador.
 */
package avaliacao;

import java.util.Random;
import java.util.Scanner;

public class Dados {
    
    public static void main(String[] args) {
        
        Random jogarDados = new Random();
        Scanner entrada = new Scanner(System.in);
        int somaJogador = 0;
        int somaMaquina = 0; 
                    
        do {
            int dadoJogador1;
            int dadoJogador2;
            
            int dadoMaquina1 = jogarDados.nextInt(6)+1;
            int dadoMaquina2 = jogarDados.nextInt(6)+1;
            somaMaquina = dadoMaquina1 + dadoMaquina2;
        
            System.out.println("O computador jogou dados com os numeros " + dadoMaquina1 + " e " + dadoMaquina2 + " (Soma " + somaMaquina + ").");
            System.out.println("Pronto para jogar? (Digite 'SIM')");
                String jogar = entrada.nextLine();
            
                if (jogar.equalsIgnoreCase("SIM")) {
                    dadoJogador1 = jogarDados.nextInt(6)+1;
                    dadoJogador2 = jogarDados.nextInt(6)+1;
                    somaJogador = dadoJogador1 + dadoJogador2;
                    
                    System.out.println("Voce jogou dados com os numeros " + dadoJogador1 + " e " + dadoJogador2 + " (Soma " + somaJogador + ").");
                }
                else {
                    System.out.println("Jogo cancelado.");
                    return;
                }
                
           if (somaJogador > somaMaquina) {
               System.out.println("Parabens! Voce venceu. Avance uma rodada.\n\n");
           }
           
           else if (somaJogador <= somaMaquina) {
               System.out.println("Que pena! Voce perdeu... Fim de jogo.\n\n");
           }
            
        } while (somaJogador > somaMaquina);
    }
}