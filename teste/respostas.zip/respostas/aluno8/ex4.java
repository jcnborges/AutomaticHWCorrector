/**
 * F.U.P que leia os lados de um triângulo que classifique o triângulo em:
 * equilátero, isósceles e escaleno.
 */

package avaliacao;

import java.util.Scanner;

public class Triangulo {
    
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        float[] vetorLados = new float[3];
        
        System.out.println("Digite os valores dos tres lados do triangulo: ");
        
        for(int i = 0; i<3; i++) {
                vetorLados[i] = entrada.nextFloat();
        }
        
        if(vetorLados[0] == vetorLados[1] && vetorLados[0] == vetorLados[2]) {
            System.out.println("Triangulo classificado como equilatero.");
        }
        
        else if (vetorLados[0] == vetorLados[1] || vetorLados[0] == vetorLados[2] || vetorLados[1] == vetorLados[2]) {
            System.out.println("Triangulo classificado como isosceles.");
        }
        
        else {
            System.out.println("\nTriangulo classificado como escaleno.");
        }
    }
}
