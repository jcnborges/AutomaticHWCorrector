import java.util.Scanner;

public class ex001 {
    public static void main(String[] args) {
        System.out.println("Escreva um número inteiro qualquer!");

        Scanner input = new Scanner(System.in);
        int valor = input.nextInt();

        while (valor < 0) {
            System.out.println("Número não é válido. Escolha outro número!");
            valor = input.nextInt();
        }

        double deci = valor * 10;
        double centi = valor * 100;
        double mili = valor * 1000;

        System.out.println("O seu número foi " + valor);
        System.out.println("O valor em decímetros " + deci);
        System.out.println("O valor em centímetros " + centi);
        System.out.println("O valor em milímetros " + mili);

        input.close();
    }
}