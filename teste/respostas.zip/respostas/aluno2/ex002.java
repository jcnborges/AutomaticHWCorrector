//Exercício 2: F.U.P que imprime uma tabela com a tabuada de 1 a 9.

//import java.util.Scanner;

public class ex002 {
    public static void main(String[] args) {

        /*
         * System.out.println("Digite um número inteiro para fazer as tabuadas:");
         * Scanner input = new Scanner(System.in);
         * int multiplicador = input.nextInt();
         * 
         * if (multiplicador<0) {
         * System.out.println("Valor inválido, escolha outro número:");
         * multiplicador = input.nextInt();
         * }
         */
        for (int i = 1; i <= 9; i++) {
            for (int m = 1; m <= 12; m++) {
                System.out.println("Tabuada do " + i + ": " + i + " *" + m + " = " + i * m);
            }

        }

        // input.close();
    }
}
