/*Exercício 8: F.U.P que implemente um jogo de dois dados contra o computador. O jogador avança as 
rodadas caso a soma de seus dados seja maior que a do computador */

import java.util.Random;
import java.util.Scanner;

public class ex008 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random numeros = new Random();
        int userPoints = 0;
        boolean gameOn = true;

        System.out.println("Digite 'girar' para rolar os dados e jogar contra os dados do computador!");

        while (gameOn) {
            String userString = input.next();

            if (userString.equals("girar")) {
                int userDice = numeros.nextInt(11) + 1;
                int computerDice = numeros.nextInt(11) + 1;

                System.out.println("Você jogou: " + userDice + ", Computador jogou: " + computerDice);

                if (userDice > computerDice) {
                    userPoints++;
                    System.out.println("Seu número foi maior! Sua pontuação agora é: " + userPoints
                            + ". Escreva 'girar' novamente para continuar jogando.");
                } else if (userDice < computerDice) {
                    System.out.println("Seu número foi menor! Sua pontuação final foi: " + userPoints
                            + ". Jogo encerrado.");
                    gameOn = false;
                } else {
                    System.out.println("Números iguais, digite 'girar' novamente para continuar jogando!");
                }
            } else {
                System.out.println("Comando inválido. Por favor, escreva a palavra 'girar' para jogar!");
            }
        }

        input.close();
    }
}
