/*Exercício 7: F.U.P que implemente um jogo de jóquei pow (pedra, papel e tesoura) contra o 
computador. O programa implementa um jogo do tipo “melhor de três”. */

import java.util.Random;
import java.util.Scanner;

public class ex007 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random movimento = new Random();

        int userPoints = 0;
        int computerPoints = 0;

        String[] computerArray = { "pedra", "papel", "tesoura" };

        System.out.println("Pedra, Papel e Tesoura!");

        boolean gameOn = true;
        while (gameOn) {
            System.out.println("Digite pedra, papel ou tesoura:");
            String userMove = input.next().toLowerCase(); // Pega e converte para minúsculas na mesma linha

            int indexMove = movimento.nextInt(3); // Gera um índice de 0 a 2
            String computerMove = computerArray[indexMove];

            if (userPoints < 3 && computerPoints < 3) {
                switch (userMove) {
                    case "pedra":
                        if (computerMove.equals("tesoura")) {
                            userPoints++;
                            System.out.println("Você ganhou! Você jogou pedra enquanto seu oponente jogou tesoura.");
                        } else if (computerMove.equals("papel")) {
                            computerPoints++;
                            System.out.println("Você perdeu. Você jogou pedra enquanto seu oponente jogou papel.");
                        } else {
                            System.out.println("Empate! Ambos jogaram pedra.");
                        }
                        break;
                    case "papel":
                        if (computerMove.equals("pedra")) {
                            userPoints++;
                            System.out.println("Você ganhou! Você jogou papel enquanto seu oponente jogou pedra.");
                        } else if (computerMove.equals("tesoura")) {
                            computerPoints++;
                            System.out.println("Você perdeu. Você jogou papel enquanto seu oponente jogou tesoura.");
                        } else {
                            System.out.println("Empate! Ambos jogaram papel.");
                        }
                        break;
                    case "tesoura":
                        if (computerMove.equals("papel")) {
                            userPoints++;
                            System.out.println("Você ganhou! Você jogou tesoura enquanto seu oponente jogou papel.");
                        } else if (computerMove.equals("pedra")) {
                            computerPoints++;
                            System.out.println("Você perdeu. Você jogou tesoura enquanto seu oponente jogou pedra.");
                        } else {
                            System.out.println("Empate! Ambos jogaram tesoura.");
                        }
                        break;
                    default:
                        System.out.println("Movimento inválido. Por favor, digite pedra, papel ou tesoura.");
                        break;
                }
                System.out.println("Placar: Você " + userPoints + ", Computador " + computerPoints);
            } else {
                gameOn = false;
            }
        }

        System.out
                .println("Fim de Jogo! Sua pontuação foi: " + userPoints + " e a do computador foi: " + computerPoints);
        input.close();
    }
}
