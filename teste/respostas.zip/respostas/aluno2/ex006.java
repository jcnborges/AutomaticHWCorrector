/*Exercício 6: F.U.P que pergunta o nome, o endereço, o telefone e a idade de uma pessoa e monta uma 
string com a seguinte frase: "Seu nome é ..., você tem ... anos, mora na rua ... e seu telefone é ... ".
 */

import java.util.Scanner;

public class ex006 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Digite seu nome:");
        String nome = input.nextLine();

        System.out.println("Digite sua idade:");
        int idade = input.nextInt();
        input.nextLine(); // Consome a quebra de linha deixada pelo nextInt()

        System.out.println("Digite seu endereço:");
        String endereco = input.nextLine();

        System.out.println("Digite seu telefone:");
        String telefone = input.nextLine();

        System.out.println("Seu nome é " + nome + ", você tem " + idade + " anos, mora na rua " + endereco
                + " e seu telefone é " + telefone);

        input.close(); // Apenas um fechamento necessário
    }
}