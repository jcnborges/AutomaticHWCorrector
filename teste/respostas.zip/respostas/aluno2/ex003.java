/*Exercício 3: F.U.P que leia 10 números decimais e armazene-os em um vetor, (i) calcule a média dos 
números lidos, (ii) mostre o maior e o (iii) menor número. */

import java.util.Scanner;

public class ex003 {
    public static void main(String[] args) {
        double[] vetor = new double[10];
        double soma = 0;

        Scanner input = new Scanner(System.in);

        System.out.println("Escreva 10 números:");

        for (int i = 1; i < 10; i++) {
            vetor[i] = input.nextDouble();
        }

        for (int i = 0; i < vetor.length; i++) {
            soma = soma + vetor[i];
        }

        double media = soma / vetor.length;
        double maiorNum = 0;
        double menorNum = 0;

        for (int i = 0; i < vetor.length; i++) {
            if (maiorNum < vetor[i]) {
                maiorNum = vetor[i];
                menorNum = maiorNum;
            }

        }

        for (int i = 0; i < vetor.length; i++) {
            if (menorNum > vetor[i]) {
                menorNum = vetor[i];
            }
        }

        System.out.print("Seu vetor é: ");
        for (int i = 1; i < 10; i++) {
            System.out.println(vetor[i]);
        }

        System.out.println("A soma total foi: " + soma);
        System.out.println("A média de todos os valores é: " + media);
        System.out.println("O maior número é: " + maiorNum);
        System.out.println("O menor número é: " + menorNum);

        input.close();
    }
}