import java.util.Scanner;

public class ex004 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] lados = new int[3];

        System.out.println("Digite três valores inteiros, um para cada lado do triângulo:");
        for (int i = 0; i < lados.length; i++) {
            lados[i] = input.nextInt();
        }

        input.close();

        if (lados[0] + lados[1] <= lados[2] || lados[0] + lados[2] <= lados[1] || lados[1] + lados[2] <= lados[0]) {
            System.out.println("Os valores fornecidos não formam um triângulo.");

        } else if (lados[0] == lados[1] && lados[1] == lados[2]) {
            System.out.println("O triângulo é equilátero.");

        } else if (lados[0] == lados[1] || lados[1] == lados[2] || lados[0] == lados[2]) {
            System.out.println("O triângulo é isósceles.");

        } else {
            System.out.println("O triângulo é escaleno.");
        }
    }
}