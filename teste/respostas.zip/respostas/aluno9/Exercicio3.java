package com.mycompany.listaexercicio1;

import java.util.Scanner;
import java.util.Locale;

public class Exercicio3 {

    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Scanner entrada = new Scanner(System.in);
        float[] vetor = new float[10];
        float maior = 0;
        float menor = 0;
        float media = 0;
        for (int i = 0; i < 10; i++) {
            System.out.println("Digite o " + i + "numero: ");
            vetor[i] = entrada.nextFloat();
            media += vetor[i];
            if (i == 0) {
                maior = vetor[i];
                menor = vetor[i];
            } else {
                if (vetor[i] > maior) {
                    maior = vetor[i];

                } else {
                    if (vetor[i] < menor) {
                        menor = vetor[i];
                    }

                }

            }

        }
        System.out.println("Media:" + media);
        System.out.println("maior:" + maior);
        System.out.println("Menor:" + menor);

    }
}
