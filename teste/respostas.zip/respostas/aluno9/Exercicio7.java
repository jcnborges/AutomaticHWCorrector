package exemplosoftware;

import java.util.Scanner;
import java.util.Random;

// 1 - pedra 
// 2 - papel 
// 3 tesoura

public class Exercicio7 {

    static class Jogador {
        private String nome;
        protected int jogada;
        private int pontos = 0;

        Jogador(String nome){
            this.nome = nome;

        }

        public int getJogada() {
            return jogada;
        }

        public void setJogada() {
            System.out.print("Digite a sua jogada: ");
            Scanner c = new Scanner(System.in);
            this.jogada = c.nextInt();
            if(jogada <1 || jogada  >3){
                System.out.println("Numero Invalido Digite outro numero:");
                this.jogada = c.nextInt();
            }
        }

        public int getPontos() {
            return pontos;
        }

        public void ganhaPontos() {
            this.pontos ++;
        }

        public String getNome(){

            return this.nome;
        }

        public void converteJogada(int a) {
            String c = null;
            switch (a) {
                case 1:
                    c = "Pedra";
                    break;
                case 2:
                    c = "Papel";
                    break;
                case 3:
                    c = "Tesoura";
                    break;
            }
            System.out.print(c);
        }



    }

    static class Computador extends Jogador {

        Computador(String nome) {
            super(nome);
        }

        @Override
        public void setJogada() {
            Random aleatorio = new Random();
            this.jogada = aleatorio.nextInt(3) + 1;

        }



    }    
    
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        int jogadas = 0;

        System.out.println("----------------------JOCKEY POW----------------------");
        System.out.println("Digite o seu nome: ");
        String nome = c.nextLine();
        System.out.println("Opcoes de jogadas");
        System.out.println("1 - Pedra; 2- Papel; 3- Tesoura");
        Jogador jogador1 = new Jogador(nome);
        Computador jogador2 = new Computador("Computador");

        while (jogadas < 3) {
            jogador1.setJogada();
            jogador2.setJogada();
            verifica(jogador1, jogador2);
            jogadas++;
            System.out.println();
            System.out.println("----------------------JOCKEY POW----------------------");
        }
        verificaGanhador(jogador1, jogador2);

    }

    public static void verifica(Jogador a, Computador b) {
        if (a.getJogada() == b.getJogada()) {
            System.out.println("Empate");
        } else if (a.getJogada() == 1 && b.getJogada() == 3 || a.getJogada() == 2 && b.getJogada() == 1 || a.getJogada() == 3 && b.getJogada() == 2) {
            a.ganhaPontos();
            System.out.println("o Jogador: " + a.getNome() + " ganhou a rodada");
            System.out.print("O computador jogou:");
            b.converteJogada(b.getJogada());
        } else {
            b.ganhaPontos();
            System.out.println("O computador venceu a  rodada");
            System.out.print("O computador jogou:");
            b.converteJogada(b.getJogada());
        }
    }

    public static void verificaGanhador(Jogador a, Computador b) {
        if (a.getPontos() > b.getPontos()) {
            System.out.println("O jogador:" + a.getNome() + "Ganhou o jogo" + "Com " + a.getPontos() + "Pontos" + "\n" + "Parabens!!!!");
        } else {
            System.out.println("Que peninha =( \n" + "O Computador venceu");
        }

    }

}
// 1 - pedra 
// 2 - papel 
// 3 tesoura
