

package com.mycompany.listaexercicio1;
import java.util.Locale;
import java.util.Scanner;

public class ListaExercicio1 {

    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Scanner entrada = new Scanner(System.in);
        System.out.println("Digite um valor em metros:");
        double metros;
        metros = entrada.nextDouble();
        double decimetro = metros*10;
        double centimetro = metros *100.00;
        double milimetro = metros *1000.00;
        System.out.println("O valor em decímetro: " + String.format("%.2f", decimetro));
        System.out.println("O valor em decímetro: " + String.format("%.2f", centimetro));
        System.out.println("O valor em decímetro: " + String.format("%.2f", milimetro));
    }
}
