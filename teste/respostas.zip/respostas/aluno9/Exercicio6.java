package com.mycompany.listaexercicio1;

import java.util.Scanner;

public class Exercicio6 {

    public static void main(String[] args) {
        String nome;
        String endereco;
        int idade;
        int telefone;

        Scanner c = new Scanner(System.in);
        System.out.println("Digite o seu nome:");
        nome = c.nextLine();
        System.out.println("Digite a sua idade:");
        idade = c.nextInt();
        c.nextLine();
        System.out.println("Digite o seu endereco:");
        endereco = c.nextLine();
        System.out.println("Digite o seu telefone");
        telefone = c.nextInt();
        System.out.printf("O seu nome e %s, voce tem %d anos, mora na rua %s, e seu telefone e %d", nome, idade, endereco, telefone);
        
        

    }

}
