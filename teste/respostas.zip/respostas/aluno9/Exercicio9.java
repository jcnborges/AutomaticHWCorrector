/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exemplosoftware;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author julio
 */
public class Exercicio9 {
   
    static class Jogador {
        private String nome;
        int dado1;
        int dado2;
        private int soma;
        Scanner a = new Scanner(System.in);
        Jogador(String a){
            this.nome = a;
        }
    //     atribui n aleatorios para os dados
        public void setDado1(){
           System.out.println("Digite o seu dado");
           this.dado1 = a.nextInt();
        }
        public void setDado2(){
             System.out.println("Digite o seu dado");
           this.dado2 = a.nextInt();
        }

        // Soma
        public void setSoma(){
           this.soma = this.dado1 + this.dado2;
        }

        // getters 

        public int getDado1() {
            return dado1;
        }

        public int getDado2() {
            return dado2;
        }

        public int getSoma() {
            return soma;
        }

        public String getNome() {
            return nome;
        }


    }    
    
    static class Computador extends Jogador {

        Computador(String a){
            super(a);
        }

        @Override
          public void setDado1(){
            Random b = new Random();
            this.dado1 = b.nextInt(5)+1;
        }
        @Override
        public void setDado2(){
            Random c = new Random();
            this.dado2 = c.nextInt(5)+1;
        }
    }  
    
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        int rodadas = 10;
        System.out.println("_____DADOS_____");
        System.out.println("Digite o seu nome: ");
        String a = c.nextLine();
        Jogador jogador1 = new Jogador(a);
        Computador jogador2 = new Computador("Computador");

        for (int i = 0; i < rodadas; i++) {
            System.out.println("Rodada: " + (i+1));
            do {
                System.out.println("Sorteando os dados....");
                jogador1.setDado1();
                jogador1.setDado2();
                jogador2.setDado1();
                jogador2.setDado2();
                jogador1.setSoma();
                jogador2.setSoma();
                System.out.println("Seus Dados: " + jogador1.getDado1() + ", " + jogador1.getDado2() + " Soma: " + jogador1.getSoma());
                System.out.println("Dados do Computador: " + jogador2.getDado1() + ", " + jogador2.getDado2() + " Soma: " + jogador2.getSoma());
            } while (jogador1.getSoma() < jogador2.getSoma());
                
        }

    }    
}

