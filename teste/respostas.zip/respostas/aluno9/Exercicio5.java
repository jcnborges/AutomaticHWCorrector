package com.mycompany.listaexercicio1;

import java.util.Random;
import java.util.Scanner;

public class Exercicio5 {

    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        Random aleatorio = new Random();
        int numx = aleatorio.nextInt(100) + 1;
        int count = 0;
        System.out.println("Digite o seu numero secreto");
        int numAd = c.nextInt();
        count++;
        while (numAd != numx) {
            if(numAd > numx){
                System.out.println("Numero maior que o Aleatorio");
            }else{
                System.out.println("O numero é menor que o aleatorio.");
            }
            numAd = c.nextInt();
            count++;
        }
        System.out.println("Voce acertou !!!!!!!");
        System.out.println("Em " + count + " Tentativas");
    }

}
