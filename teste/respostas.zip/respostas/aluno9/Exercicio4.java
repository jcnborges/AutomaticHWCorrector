

package com.mycompany.listaexercicio1;
import java.util.Scanner;


public class Exercicio4 {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        int l1;
        int l2,l3;
        System.out.println("Digite os 3 lados do seu Triangulo");
        l1 = c.nextInt();
        l2 = c.nextInt();
        l3 = c.nextInt();
        if(l1 == l2 && l2 == l3){
            System.out.println("O seu triangulo é equilatero");
        }else if ( l1 == l2 && l1 != l3 || l2 == l3 && l2 != l1 || l1 == l3 && l1 != l2 ){
            System.out.println("O seu triangulo é isosceles ");
        }else{
            System.out.println("O seu triangulo é Escaleno");
        }
        
       
        
    }
    
}
