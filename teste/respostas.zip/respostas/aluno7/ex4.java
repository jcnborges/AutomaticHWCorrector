package classes;

import java.util.Scanner;

public class ladosProgPrincipal {

    public static void main(String[] args) {

        int[] num = new int[3];

        Scanner leitura = new Scanner(System.in);

        System.out.println("Digite os lados de um triangulo");

        for (int i = 1; i <= num.length; i++)
        {
            System.out.println("\tDigite o lado " + i);
            num[i - 1] = leitura.nextInt();
        }

        if (num[0] == num[1] && num[0] == num[2] && num[1] == num[2])
        {
            System.out.println("Triangulo Equilatero");
        }
        else if(num[0] != num[1] && num[0] != num[2] && num[1] != num[2]){
            System.out.println("Triangulo escaleno.");
        }
        else{
            System.out.println("Triangulo isosceles");
        }
       leitura.close();
    }
}


