package classes;

import java.util.Random;
import java.util.Scanner;

public class dados {

    /*Exercício 8: F.U.P que implemente um jogo de dois dados contra o computador. O jogador avança as 
rodadas caso a soma de seus dados seja maior que a do computador*/
    public static void main(String[] args) {

        int num;
        int leitura;
        int rodada = 0;
        Random aleatorio = new Random();
        Scanner input = new Scanner(System.in);
        num = aleatorio.nextInt(6) + 1;

        
        while (true)
        {
            System.out.println("\tDigite um numero: ");
            leitura = input.nextInt();
        
            if (leitura < num)
            {
                System.out.println("\tPerdeu! o numero digitado e muito pequeno");
                break;
                
            } else if (leitura > num)
            {
                ++rodada;
                System.out.println("\tBela jogada vamos para proxima rodada " + rodada);
                num = aleatorio.nextInt(6) + 1;
                
            }
            else {
                System.out.println("Empate!");
                break;
            }
        }
    }

}
