package classes;

import java.util.Scanner;

public class joqueipow {

    /*Exercício 7: F.U.P que implemente um jogo de jóquei pow (pedra, papel e tesoura) contra o 
    computador. O programa implementa um jogo do tipo “melhor de três”.*/
    
    public static void main(String[] args) {
        
        Scanner leitura = new Scanner(System.in);

        int numeroAleatorio = (int) (Math.random() * 3) + 1;

        switch (numeroAleatorio)
        {
            case 1:
                System.out.println("\tPedra");
                break;
            case 2:
                System.out.println("\tPapel");
                break;
            case 3:
                System.out.println("\tTesoura");
                break;
            default:
                break;
        }
        

        System.out.println("Insira 1 para pedra, 2 para papel e 3 para tesoura");
        int num = leitura.nextInt();

        if (num == numeroAleatorio)
        {
            System.out.println("Empatou");
        } else if ((num == 1 && numeroAleatorio == 3) || (num == 2 && numeroAleatorio == 1) || (num == 3 && numeroAleatorio == 2))
        {
            System.out.println("Ganhou");
        }
        else{
            System.out.println("Perdeu!");
        }
        
    }

}
