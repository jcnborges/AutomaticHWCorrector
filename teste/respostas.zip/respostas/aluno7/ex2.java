/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package classes;

//Exercício 2: F.U.P que imprime uma tabela com a tabuada de 1 a 9.

public class TabProg {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        for(int i = 1; i <= 9; i++){ // primeiro número
            System.out.println("Tabuada do: " + i);
                            System.out.println("");
            for(int j = 1; j <= 10; j++){ // multiplicar com segundo
                System.out.println("\t" + i + " x " + j + " = " + i*j);

            }
                            System.out.println("");
        }
    }
    
}
