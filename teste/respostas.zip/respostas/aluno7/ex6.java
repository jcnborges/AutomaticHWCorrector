

package classes;
    import java.util.Scanner;

public class dadosPessoais {

    /* Exercício 6: F.U.P que pergunta o nome, o endereço, o telefone e a idade de uma pessoa e monta uma 
    string com a seguinte frase: "Seu nome é ..., você tem ... anos, mora na rua ... e seu telefone é ... ".*/
    
    public static void main(String[] args) {
        
        String nome;
        String endereco;
        String frase;
        int idade;
        int telefone = 0;
        
        Scanner leitura = new Scanner(System.in);
        
        System.out.println("Qual seu nome? ");
        nome = leitura.nextLine();
        System.out.println("Qual seu endereco? ");
        endereco = leitura.nextLine();
        System.out.println("Qual seu telefone? ");
        telefone = leitura.nextInt();
        System.out.println("Qual sua idade?");
        idade = leitura.nextInt();
        
        frase = "Seu nome e: " + nome + " voce tem " + idade + " anos, mora na rua " + endereco + " e seu telefone e " + telefone;
        System.out.println(frase);
    }
    
}
