
package classes;

import java.util.Scanner;

/*F.U.P que leia 10 números decimais e armazene-os em um vetor, (i) calcule a média dos 
    números lidos, (ii) mostre o maior e o (iii) menor número*/

public class medMaiorMenor {


    public static void main(String[] args) {

        float [] num = new float[10];
        float med = 0;
        float maior = 0;
        float menor = 100;
        float soma = 0;

        System.out.println("Insira 10 numeros decimais a seguir:");
        Scanner leitura = new Scanner(System.in);

        for (int i = 0; i < 10; i++){
            
            num[i] = leitura.nextFloat();
            soma = soma + num[i];
            
            if(num[i] > maior){
                maior = num[i];
            }
            if(num[i] < menor){
                menor = num[i];
            }
        }
        med = soma / num.length;
            System.out.println("Maior : " + maior + " Menor : " + menor + " Media: " + med);
    }

}
