/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package classes;

import java.util.Scanner;

    /*Faça um programa em Java (F.U.P) que pergunta um valor em metros e imprime o 
    correspondente em decímetros, centímetros e milímetros+*/

public class ProgPrincipal {

    
    public static void main(String[] args) {
        
        
        Scanner texto = new Scanner(System.in);
        System.out.println("Digite um valor: ");
        
        int num = texto.nextInt();
        
        
        System.out.println("Valor em cm: " + num * 100);
        System.out.println("Valor em dm: " + num * 10);
        System.out.println("Valor em mm: " + num * 1000);
        
    }
    
}
