

package classes;
 import java.util.Random;
 import java.util.Scanner;

public class advProgPrincilpal {
        
    /*Exercício 5: F.U.P que simule um jogo de adivinhação. O programa inicializa sorteando um número 
    de 1 a 100. Depois, o usuário digita um palpite até acertar o número. Para cada palpite, o programa 
    indica se o número digitado é maior ou menor que o número sorteado. No final, o programa mostra 
    quantas tentativas o usuário precisou para acertar.
    */
    
    public static void main(String[] args) {
        int valor;
        boolean acerto = false;
        int tentativa = 0;
        Random adivinha = new Random();
        Scanner leitura = new Scanner(System.in);
        
           int num = adivinha.nextInt(100) + 1;
            System.out.println(num);
        
        System.out.println("Digite um numero aleatorio de 1 a 100: ");
        
        
        while(!acerto){
            valor = leitura.nextInt();
            if(valor == num){
                System.out.println("Voce acertou! o numero e: " + valor);
                acerto = true;
            }
            else if(valor < num){
                System.out.println("O numero e maior que " + valor);
                ++tentativa;
            }
            else if(valor > num){
                System.out.println("O numero e menor que " + valor);
               ++tentativa;
            }
        }
        leitura.close();
        System.out.println("Quantidade de tentativas: " + tentativa);
    }
    
}
