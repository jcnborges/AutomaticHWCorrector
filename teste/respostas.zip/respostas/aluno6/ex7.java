import java.util.Random;
import java.util.Scanner;

public class JoqueiPow {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        int rodadas = 3;
        int vitoriaPlayer = 0;
        int vitoriasPC = 0;

        System.out.println("Vamos jogar, Joquei Pow. Quem vencer três rodadas, ganha.");
        for (int rod = 1; rod <= rodadas; rod++) {
            System.out.println("Rodada " + rod + ": Escolha pedra, papel ou tesoura:");
            System.out.print("1. Pedra\n2. Papel\n3. Tesoura\nSua escolha: ");
            int escolhaPlayer = scanner.nextInt();

            int escolhaPC = random.nextInt(3) + 1;

            System.out.println("O computador escolheu: " + escolhaPC);

            if (escolhaPlayer == escolhaPC) {
                System.out.println("Empate nesta rodada!");
            } else if ((escolhaPlayer == 1 && escolhaPC == 3) ||
                    (escolhaPlayer == 2 && escolhaPC == 1) ||
                    (escolhaPlayer == 3 && escolhaPC == 2)) {
                vitoriaPlayer++;
                System.out.println("Você ganhou esta rodada!");
            } else {
                vitoriasPC++;
                System.out.println("O computador ganhou esta rodada!");
            }
        }

        if (vitoriaPlayer > vitoriasPC) {
            System.out.println("Parabéns, você ganhou o jogo!");
        } else if (vitoriasPC > vitoriaPlayer) {
            System.out.println("Computador ganhou o jogo. Boa sorte na próxima!");
        } else {
            System.out.println("O jogo terminou em empate. Quer tentar novamente?");
        }

        scanner.close();
    }
}
