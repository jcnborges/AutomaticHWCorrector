import java.util.Random;
import java.util.Scanner;

public class Adivinha {
	public static void main(String[] args) {
		Random gerador = new Random();
		Scanner entrada = new Scanner(System.in);
		int numero = gerador.nextInt(11);
		int palpite;

		System.out.println("Estou pensando em um número aleatório de 0 a 10 e seu objetivo é adivinhar qual é.\nQual seu palpite?");
        do {
            palpite = entrada.nextInt();

            if (palpite > numero) {
                System.out.println("O número é menor.");
            } else if (palpite < numero) {
                System.out.println("O número é maior.");
            } else {
                System.out.println("Parabéns, você acertou!");
            }
        } while (palpite != numero);

        entrada.close();
    }
}