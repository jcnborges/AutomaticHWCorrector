import java.util.Scanner;

public class Decimais {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double[] numeros = new double[10];
        double soma = 0;
        double media = soma / 10;
        double maior = numeros[0];
        double menor = numeros[0];

        for (int i = 0; i < 10; i++) {
            System.out.print("Digite um número: ");
            numeros[i] = entrada.nextDouble();
            soma += numeros[i];
        }
    
        for (int i = 1; i < 10; i++) {
            if (numeros[i] < menor) {
                menor = numeros[i];
            }
            if (numeros[i] > maior) {
                maior = numeros[i];
            }
        }

        System.out.println("Média dos números: " + media);
        System.out.println("Maior número: " + maior);
        System.out.println("Menor número: " + menor);

        entrada.close();
    }
}