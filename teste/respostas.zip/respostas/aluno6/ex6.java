import java.util.Scanner;

public class DadosPessoais {
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		String nome;
		String rua;
		String fone;
		int idade;

		System.out.println("Qual seu nome? ");
		nome = entrada.nextLine();

		System.out.println("Quantos anos você tem? ");
		idade = entrada.nextInt();
		entrada.nextLine();

		System.out.println("Qual o nome da rua onde você mora? ");
		rua = entrada.nextLine();

		System.out.println("Qual seu telefone (sem DDD)? ");
		fone = entrada.nextLine();

		System.out.println("Seu nome é " + nome + ", você tem " + idade + " anos, mora na rua " + rua + " e seu telefone é 41" + fone + ".");

		entrada.close();
	}
}