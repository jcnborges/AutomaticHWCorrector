import java.util.Scanner;

public class Triangulos {
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		double a, b, c;


		System.out.println("Digite o 1° lado ");
		a = entrada.nextDouble();

		System.out.println("Digite o 2° lado ");
		b = entrada.nextDouble();

		System.out.println("Digite o 3° lado ");
		c = entrada.nextDouble();

		if (a == b && b == c) {
			System.out.println("Triângulo Equilátero");
		} else if(a == b || a == c || b == c) {
			System.out.println("Triângulo Isóceles");
		} else {
			System.out.println("Triângulo Escaleno");
		}
		entrada.close();	
	}
}