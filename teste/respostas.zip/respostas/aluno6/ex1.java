import java.util.Scanner;

public class Conversor {
  public static void main(String args[]){

    Scanner entrada = new Scanner(System.in);

    System.out.print("Insira uma medida em metros: ");
    float metros = entrada.nextFloat();

  	double decimetros = metros * 10;
    double centimetros = metros * 100;
    double milimetros = metros * 1000;



   	System.out.println("Valor em decímetros: " + decimetros);
    System.out.println("Valor em centímetros: " + centimetros);
    System.out.println("Valor em milímetros: " + milimetros);
	
	 entrada.close();
 }
}