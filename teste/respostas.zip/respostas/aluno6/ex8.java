import java.util.Random;
import java.util.Scanner;

public class JogoDados {
    public static void main(String[] args) {
    	Scanner entrada = new Scanner(System.in);
    	Random random = new Random();

    	System.out.println("Vamos jogar! Seu objetivo é tirar dois dados e a soma deve ser maior que a dos meus. ");

    	while (true){
    		System.out.println("Pressione Enter para lançar os dados...");
    		entrada.nextLine();

    		int dadoPlayer1 = random.nextInt(6) + 1;
            int dadoPlayer2 = random.nextInt(6) + 1;
            int dadoPC1 = random.nextInt(6) + 1;
            int dadoPC2 = random.nextInt(6) + 1;

            int somaPlayer = dadoPlayer1 + dadoPlayer2;
            int somaPC = dadoPC1 + dadoPC2;

            System.out.println("Você: " + dadoPlayer1 + " + " + dadoPlayer2 + " = " + somaPlayer);
            System.out.println("Computador: " + dadoPC1 + " + " + dadoPC2 + " = " + somaPC);
    	
    		if (somaPlayer > somaPC){
    			System.out.println("Você ganhou! Parabéns.");
    		} else if (somaPlayer < somaPC){
    			System.out.println("O comptador ganhou. Mais sorte na próxima...");
    		} else{
    			System.out.println("Empate. Vamos jogar de novo?");
    		}
    		break;
    	}
    	entrada.close();
    }
}