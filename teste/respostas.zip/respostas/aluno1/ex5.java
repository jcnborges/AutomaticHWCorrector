import java.util.Random;
import java.util.Scanner;

public class ex5 {
    public static void main(String[] args){
        Random rd = new Random();
        Integer num = rd.nextInt(100) + 1, palpite, cont = 0;
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("Digite um numero: ");
            palpite = sc.nextInt();
            cont++;
            if (palpite < num) {
                System.out.println("O numero certo é maior.");
            }
            else if (palpite > num) {
                System.out.println("O numero certo é menor.");
            }
            else{
                System.out.println("Parabens, você acertou em " + cont + " tentativas!");
                break;
            }
        }
    }
}
