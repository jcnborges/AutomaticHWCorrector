import java.util.Random;
import java.util.Scanner;

public class ex7 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        Integer ptsPlayer = 0, ptsPc = 0;
        while (true) {
            System.out.println("1 - Pedra \n2 - Papel \n3 - Tesoura");
            Integer player = sc.nextInt(), pc = rand.nextInt(3) + 1;
            System.out.println("Sua jogada foi: " + ((player == 1) ? "Pedra" : (player == 2) ? "Papel" : "Tesoura"));
            System.out.println("A jogada do computador foi: " + ((pc == 1) ? "Pedra" : (pc == 2) ? "Papel" : "Tesoura"));
            if (player == pc) {
                System.out.println("Empate!");
            }
            else if ((player == 1 && pc == 2) || (player == 2 && pc == 3) || (player == 3 && pc == 1)) {
                System.out.println("Você perdeu!");
                ptsPc++;
            }
            else if ((player == 1 && pc == 3) || (player == 2 && pc == 1) || (player == 3 && pc == 2)) {
                System.out.println("Você ganhou!");
                ptsPlayer++;
            }
            System.out.println("Seus pontos: " + ptsPlayer + "\nPontos do computador: " + ptsPc);
            if (ptsPc >= 3 || ptsPlayer >= 3) {
                System.out.println("Fim de jogo.");
                break;
            }
        }
    }
}
