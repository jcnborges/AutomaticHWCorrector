import java.util.Scanner;

public class ex4 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        Integer num[] = new Integer[3];
        for(Integer i = 0; i<3; i++){
            System.out.println("Digite o " + (i+1) + " lado: ");
            num[i] = sc.nextInt();
        }
        if (num[0] == num[1] && num[0] == num[2]) {
            System.out.println("O triangulo é Equilátero.");
        }
        else if (num[0] == num[1] || num[0] == num[2] || num[1] == num[2]) {
            System.out.println("O triangulo é Isósceles.");
        }
        else{
            System.out.println("O triangulo é Escaleno.");
        }
    }
}