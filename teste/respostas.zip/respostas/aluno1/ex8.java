import java.util.Random;
import java.util.Scanner;

public class ex8 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        Integer somaPlayer = 0, somaPc = 0;
        for(int i = 0; i<2; i++){
            System.out.println("Pressione enter para jogar o " + (i+1) + "° dado.");
            sc.nextLine();
            Integer dadoPlayer = rand.nextInt(6) + 1, dadoPc = rand.nextInt(6) + 1;
            somaPlayer += dadoPlayer;
            somaPc += dadoPc;
            System.out.println("Seu dado foi: " + dadoPlayer + "\nO dado do computador foi: " + dadoPc);
        }
        System.out.println("Você somou " + somaPlayer + " pontos. \nO computador somou " + somaPc + " pontos.");
        System.out.println((somaPlayer < somaPc) ? "Você perdeu!" : (somaPlayer > somaPc) ? "Você ganhou!" : "Empate!");
    }
}