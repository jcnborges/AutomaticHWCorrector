import java.util.Scanner;

public class ex3 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        Double num[] = new Double[10], soma = 0.0, maior = 0.0, menor = 999999999.0;
        for(Integer i = 0; i<10; i++){
            num[i] = sc.nextDouble();
            soma += num[i];
            maior = (num[i] > maior) ? num[i] : maior;
            menor = (num[i] < menor) ? num[i] : menor;
        }
        System.out.println("Media: " + soma / 10);
        System.out.println("Maior numero: " + maior);
        System.out.println("Menor numero: " + menor);
    }
}