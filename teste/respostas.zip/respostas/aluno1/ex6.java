import java.util.Scanner;

public class ex6 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite seu nome: ");
        String nome = sc.nextLine();
        System.out.println("Digite sua idade: ");
        String idade = sc.nextLine();
        System.out.println("Digite sua rua: ");
        String rua = sc.nextLine();
        System.out.println("Digite seu telefone: ");
        String telefone = sc.nextLine();
        System.out.println("Seu nome é " + nome + ", você tem " + idade + " anos, mora na rua " + rua + " e seu telefone é " + telefone);
    }
}
