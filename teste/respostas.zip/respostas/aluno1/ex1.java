import java.util.Scanner;

/**
 * ex1
 */
public class ex1 {

    public static void main(String[] args){
        System.out.println("Digite um valor em metros: ");
        Scanner sc = new Scanner(System.in);
        Integer metros = sc.nextInt();
        System.out.println("Metros: " + metros + "\nDecimetros: " + metros * 10 + "\nCentimetros: " + metros * 100 + "\nMilimetros: " + metros * 1000);
    }
}