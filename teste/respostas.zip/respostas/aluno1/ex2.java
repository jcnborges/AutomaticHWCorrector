public class ex2 {
    public static void main(String[] args){
        for(Integer num = 1; num <=10; num++){
            for(Integer i = 1; i<=10; i++){
                System.out.println(num + " X " + i + " = " + num * i);
            }
            System.out.println();
        }
    }
}