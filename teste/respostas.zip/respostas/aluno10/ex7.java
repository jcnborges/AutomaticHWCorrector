/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercício7_java;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Eduardo
 */
public class Exercício7_Java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int jogada = 0;
        int vitorias = 0;
        int derrotas = 0;
        int empates = 0;
        Random computador = new Random();
        System.out.println("1 - Pedra, 2- Papel, 3- Tesoura");
        
        for(int i = 0; i < 3; i++) {
            System.out.println("Digite aqui sua jogada:");
            while (jogada != 1 && jogada != 2 && jogada != 3)  {
                Scanner leitor = new Scanner(System.in);
                jogada = leitor.nextInt();
            } 
            int jogada_PC = computador.nextInt(3) + 1;
            
            if (jogada == jogada_PC) {
                System.out.println("Houve um empate! Ele 'adivinhou' sua jogada e colou tua jogada");
                empates += 1;
                jogada = 0;
            }
            else {
                if (jogada == 2 && jogada_PC == 1) {
                    System.out.println("Voce venceu essa! O computador escolheu pedra");
                    vitorias += 1;
                    jogada = 0;
                }
                else if (jogada == 3 && jogada_PC == 2) {
                    System.out.println("Voce venceu essa! O computador escolheu papel");
                    vitorias += 1;
                    jogada = 0;
                }
                else if (jogada == 1 && jogada_PC == 3) {
                    System.out.println("Voce venceu essa! O computador escolheu tesoura");
                    vitorias += 1;
                    jogada = 0;
                }
                else {
                    if (jogada == 3 && jogada_PC == 1) {
                        System.out.println("Voce perdeu essa! O computador escolheu pedra");
                        derrotas += 1;
                        jogada = 0;
                    }
                    else if (jogada == 1 && jogada_PC == 2) {
                        System.out.println("Voce perdeu essa! O computador escolheu papel");
                        derrotas += 1;
                        jogada = 0;
                    }
                    else {
                        // Jogador = Papel e PC = Tesoura
                        System.out.println("Voce perdeu essa! O computador escolheu tesoura");
                        derrotas += 1;
                        jogada = 0;
                    }
                }
            }
            
        }
        
        if (vitorias > 1 || (vitorias > 0 && empates > 1)) {
            System.out.println("Parabens, voce ganhou o jogo!");
        }
        else if (derrotas > 1 || (derrotas > 0 && empates > 1)) {
            System.out.println("Que pena, voce perdeu o jogo");
        }
        else { // if (empates > 1 || (vitorias == derrotas && empates > 0))
            System.out.println("Que sorte e azar ao mesmo tempo! Voce empatou o jogo");
        }
    }
    
}
