/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercício5_java;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Eduardo
 */
public class Exercício5_Java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int num_maior = 0;
        int num_menor = 0;
        int tentativas = 1;
        float palpite = 0; 
        /* É float, pois você pode analisar melhor a quantia de numeros maiores e 
        menores, para uma experiência mais pura, troque-o pelo tipo int, lembrando
        que o nextFloat terá que ser nextInt após está alteração
        */
        int[] vetor_numeros = new int[100];
        Random gerador_num = new Random();
        
        for (int i = 0; i < 100; i++) {
            vetor_numeros[i] = gerador_num.nextInt(100) + 1;
        }
        for (int j = 0; j < tentativas; j++) {
            
            if (num_maior > 0 || num_menor > 0) {
                System.out.println("\nNumeros maiores que seu palpite: " + num_maior);
                System.out.println("Numeros menores que seu palpite: " + num_menor);
                num_maior = 0;
                num_menor = 0;
            }
            
            System.out.println("\nAdvinhe os numeros sorteados aqui:");
            Scanner leitor = new Scanner(System.in);
            palpite = leitor.nextFloat();
            tentativas += 1;
            for (int k = 0; k < 100; k++) {
                if (palpite == vetor_numeros[k]) {
                    tentativas -= 1;
                    System.out.println("Parabens, voce acertou o numero, voce tentou acertar " + tentativas + " vez(es)");
                    k = 100;
                    tentativas = 0;
                }
                else {
                    if (palpite < vetor_numeros[k]) {
                        num_maior += 1;
                    }
                    else {
                        num_menor += 1;
                    }
                }
            }
        }
    }
    
}
