/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercício4_java;

import java.util.Scanner;

/**
 *
 * @author Eduardo
 */
public class Exercício4_Java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        float ladoa; float ladob; float ladoc;
        Scanner identificador = new Scanner(System.in);
        System.out.println("Digite aqui o valor do lado 1 do triangulo:");
        ladoa = identificador.nextFloat();
        System.out.println("Digite aqui o valor do lado 2 do triangulo:");
        ladob = identificador.nextFloat();
        System.out.println("Digite aqui o valor do lado 3 do triangulo:");
        ladoc = identificador.nextFloat();
        
        if (ladoa != ladob && ladob != ladoc && ladoc != ladoa) {
            System.out.println("O triangulo que voce criou e um escaleno");
        }
        else if (ladoa == ladob && ladob == ladoc && ladoc == ladoa) {
            System.out.println("O triangulo que voce criou e um equilatero");
        }
        else {
            System.out.println("O triangulo que voce criou e um isosceles");
        }
    }
    
}
