/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercício3_java;

import java.util.Scanner;

/**
 *
 * @author Eduardo
 */
public class Exercício3_Java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        float vetor_numero[] = new float[10];
        float media = 0;
        
        System.out.println("Digite aqui um valor qualquer:");
        for (int i = 0; i < 10; i++) {
            
            Scanner calculador = new Scanner(System.in);
            vetor_numero[i] = calculador.nextFloat();
            media += (vetor_numero[i]);
            
        }
        
        media /= 10;
        float mn_numero = (float) (vetor_numero[0]); // Menor numero
        float mi_numero = -999999999; // Maior numero
        
        for(int j = 0; j < 10; j ++) {
            
            if (vetor_numero[j] > mi_numero || vetor_numero[j] == mi_numero) {
                mi_numero = vetor_numero[j];
            }
            else if (vetor_numero[j] < mn_numero) {
                mn_numero = vetor_numero[j];
            }
            
        }
        System.out.println("O menor numero e: " + mn_numero);
        System.out.println("O maior numero e: " + mi_numero);
        System.out.println("A media dos numeros e: " + media);
        
    }
    
}
