/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercício6_java;

import java.util.Scanner;

/**
 *
 * @author Eduardo
 */
public class Exercício6_Java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        System.out.println("Digite aqui seu nome:");
        Scanner leitor_hack = new Scanner(System.in);
        String nome = leitor_hack.nextLine();
        System.out.println("Digite aqui seu endereco:");
        String endereco = leitor_hack.nextLine();
        System.out.println("Digite aqui seu telefone:");
        String telefone = leitor_hack.nextLine();
        System.out.println("Digite aqui sua idade:");
        int idade = leitor_hack.nextInt();
        
        System.out.println("Parabens por ter me dado estes dados de graca");
        System.out.println("Agora, vou expor tudo isto no twitter:");
        System.out.println("Seu nome e " + nome + ", voce tem " + idade + " anos, mora na rua " + endereco + " e seu telefone e " + telefone);
    }
    
}
