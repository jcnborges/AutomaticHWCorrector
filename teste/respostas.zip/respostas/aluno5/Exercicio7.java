package excercicios;

import java.util.Random;
import java.util.Scanner;

import static java.lang.Thread.sleep;

public class Exercicio7 {

    private static String converterParaMinusculo(String texto) {
        final StringBuilder resultado = new StringBuilder();

        for (int i = 0; i < texto.length(); i++) {
            char caractere = texto.charAt(i);
            if (Character.isUpperCase(caractere)) {
                caractere = Character.toLowerCase(caractere);
            }
            resultado.append(caractere);
        }

        return resultado.toString();
    }

    private static String conversorIntToString(int num) {

        switch (num) {
            case 1:
                return "tesoura";

            case 2:
                return "pedra";

            case 3:
                return "papel";

            default:
                return "Erro";
        }

    }

    private static int conversorStringToInt(String escolha) {

        switch (converterParaMinusculo(escolha)) {
            case "tesoura":
                return 1;

            case "pedra":
                return 2;

            case "papel":
                return 3;

            default:
                return 0;
        }

    }

    private static void obterInformacoes() throws InterruptedException {

        final Random numero = new Random();

        int melhorDeTres = 0;
        int jogadorGanhou = 0;
        int pcGanhou = 0;
        Scanner ler = new Scanner(System.in);

        String explicacao = "Olá! Esse é um simples jogo de Jóquei Pow.\n" + "Tesoura ganha de papel\n" + "Papel ganha de pedra\n" + "Pedra ganha de tesoura\n" + "É simples, não? Então agora é sua vez!\n\n" + "Se você quer usar a tesoura digite tesoura.\n" + "Se você quer usar a pedra digite pedra.\n" + "Se você quer usar o papel digite papel.\n" + "Eu tentarei ganhar de você e isso será uma melhor de 3!\n" + "Boa sorte!\n\n";

        System.out.println(explicacao);
        sleep(1000);

        while (melhorDeTres < 3) {
            int escolhaDoPc = numero.nextInt(3) + 1;

            System.out.println("O que você escolhe?");
            String jogada = ler.nextLine();
            int jogada1 = conversorStringToInt(jogada);

            if (escolhaDoPc == jogada1) {
                System.out.println("Eu escolhi " + conversorIntToString(escolhaDoPc) + " e você escolheu " + conversorIntToString(jogada1));
                System.out.println("Empate!");
                melhorDeTres++;
            } else if (escolhaDoPc == 1 && jogada1 == 2) {
                System.out.println("Eu escolhi " + conversorIntToString(escolhaDoPc) + " e você escolheu " + conversorIntToString(jogada1));
                System.out.println("Droga, você venceu!");
                jogadorGanhou++;
                melhorDeTres++;
            } else if (escolhaDoPc == 1 && jogada1 == 3) {
                System.out.println("Eu escolhi " + conversorIntToString(escolhaDoPc) + " e você escolheu " + conversorIntToString(jogada1));
                System.out.println("Hahaha, eu venci!");
                melhorDeTres++;
                pcGanhou++;
            } else if (escolhaDoPc == 2 && jogada1 == 3) {
                System.out.println("Eu escolhi " + conversorIntToString(escolhaDoPc) + " e você escolheu " + conversorIntToString(jogada1));
                System.out.println("Droga, você venceu!");
                jogadorGanhou++;
                melhorDeTres++;
            } else if (escolhaDoPc == 2 && jogada1 == 1) {
                System.out.println("Eu escolhi " + conversorIntToString(escolhaDoPc) + " e você escolheu " + conversorIntToString(jogada1));
                System.out.println("Hahaha, eu venci!");
                melhorDeTres++;
                pcGanhou++;
            } else if (escolhaDoPc == 3 && jogada1 == 1) {
                System.out.println("Eu escolhi " + conversorIntToString(escolhaDoPc) + " e você escolheu " + conversorIntToString(jogada1));
                System.out.println("Droga, você venceu!");
                jogadorGanhou++;
                melhorDeTres++;
            } else if (escolhaDoPc == 3 && jogada1 == 2) {
                System.out.println("Eu escolhi " + conversorIntToString(escolhaDoPc) + " e você escolheu " + conversorIntToString(jogada1));
                System.out.println("Hahaha, eu venci!");
                melhorDeTres++;
                pcGanhou++;
            }

        }

        if (pcGanhou == jogadorGanhou) {
            System.out.println("Eu ganhei " + pcGanhou + " vezes e você ganhou " + jogadorGanhou + " então, empatamos!");
        } else if (pcGanhou > jogadorGanhou) {
            System.out.println("Eu ganhei " + pcGanhou + " vezes e você ganhou " + jogadorGanhou + " então, eu venço!");
        } else {
            System.out.println("Eu ganhei " + pcGanhou + " vezes e você ganhou " + jogadorGanhou + " então, eu perco!");
        }

    }

    public static void resposta() throws InterruptedException {
        obterInformacoes();
    }

}
