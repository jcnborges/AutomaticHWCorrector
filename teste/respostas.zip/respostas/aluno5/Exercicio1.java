package excercicios;

public class Exercicio1 {

    private static StringBuilder calcularValor(double metros) {

        final StringBuilder sb = new StringBuilder();

        sb.append("O valor de ").append(metros).append(" m em decímetros é: ").append(metros * 10).append(" dm\n");
        sb.append("O valor de ").append(metros).append(" m em centímetros é: ").append(metros * 100).append(" cm\n");
        sb.append("O valor de ").append(metros).append(" m em milímetros é: ").append(metros * 1000).append(" mm\n");

        return sb;
    }

    public static void resposta(double value) {

        System.out.println(calcularValor(value));
    }

}
