package excercicios;

import java.util.Random;
import java.util.Scanner;

public class Exercicio5 {

    private static StringBuilder calcularValor() {
        final StringBuilder sb = new StringBuilder();
        
        try (Scanner ler = new Scanner(System.in)) {
            
            final Random numero = new Random();
            int numeroAtual;
            int tentativas = 0;
            final int finalNumber = numero.nextInt(100);
            
            System.out.println("Tente adivinhar o número de 0 a 100:");
            
            while (true) {
                numeroAtual = ler.nextInt();
                tentativas++;

                if (numeroAtual < finalNumber) {
                    System.out.println("O número que você colocou está abaixo do número desconhecido!");
                } else if (numeroAtual > finalNumber) {
                    System.out.println("O número que você colocou está acima do número desconhecido!");
                } else {
                    sb.append("Parabéns, você acertou! O número secreto era realmente ").append(finalNumber).append("!\n");
                    sb.append("Você precisou de ").append(tentativas).append(" tentativas para acertar.\n");
                    break;
                }
            }
        }

        return sb;
    }

    public static void resposta() {
        System.out.println(calcularValor());
    }

}
