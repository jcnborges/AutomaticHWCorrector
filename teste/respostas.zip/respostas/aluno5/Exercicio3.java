package excercicios;

import java.util.Scanner;

public class Exercicio3 {

    private static StringBuilder calcularValor() {
        final StringBuilder sb = new StringBuilder();
        Scanner ler = new Scanner(System.in);

        final double[] v = new double[10];

        double soma = 0;
        double menor = Double.MAX_VALUE;
        double maior = Double.MIN_VALUE;

        for (int i = 0; i < 10; i++) {
            System.out.printf("Informe " + (i + 1) + "o. valor de 10: ");
            v[i] = ler.nextDouble();

            if (v[i] < menor) {
                menor = v[i];
            }

            if (v[i] > maior) {
                maior = v[i];
            }

            soma = soma + v[i];

        }

        sb.append("Seus valores são: ");

        final double media = soma / 10;

        for (int i = 0; i < 10; i++) {
            sb.append(v[i]).append(", ");
        }
        sb.append("\nMenor valor: ").append(menor).append("\nMaior valor: ").append(maior);
        sb.append("\nA soma é: ").append(soma);
        sb.append("\nA média é: ").append(media);

        return sb;
    }

    public static void resposta() {
        System.out.println(calcularValor());
    }

}
