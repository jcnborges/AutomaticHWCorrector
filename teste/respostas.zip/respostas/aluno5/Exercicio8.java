package excercicios;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Exercicio8 {

    private static void exercicio8() {
        Random random = new Random();
        Scanner ler = new Scanner(System.in);
        List<Integer> somasAnteriores = new ArrayList<>();
        int ganhou = 0;

        while (true) {
            int numPc1 = random.nextInt(6) + 1;
            int numPc2 = random.nextInt(6) + 1;

            int somaPc = numPc1 + numPc2;

            System.out.println("Digite dois números de 1 a 6 (a soma não pode ser igual a uma soma anterior):");
            int num1 = ler.nextInt();
            int num2 = ler.nextInt();

            int somaJogador = num1 + num2;

            if ((num1 < 1 || num1 > 6) || (num2 < 1 || num2 > 6)) {
                System.out.println("Número(s) inválido(s), você perdeu o jogo.");
                break;
            }

            if (somasAnteriores.contains(somaJogador)) {
                System.out.println("Você já usou" + somaJogador + " antes, por favor, escolha novamente.");
                continue;
            }

            somasAnteriores.add(somaJogador);

            if (somasAnteriores.size() == 11) {
                System.out.println("Você ganhou o jogo!");
                break;
            }

            if (somaJogador > somaPc) {
                System.out.println("Você ganhou esta rodada! Meus números foram " + numPc1 + " e " + numPc2 + " e a soma foi " + somaPc + ".");
                ganhou++;
            } else if (somaJogador == somaPc) {
                System.out.println("Você empatou esta rodada! Meus números foram " + numPc1 + " e " + numPc2 + " e a soma foi " + somaPc + ".");

            } else {
                System.out.println("Você perdeu esta rodada! Meus números foram " + numPc1 + " e " + numPc2 + " e a soma foi " + somaPc + ".");
                break;
            }
        }

        if (ganhou == 1) {
            System.out.println("Você ganhou " + ganhou + " vez!");
        } else {
            System.out.println("Você ganhou " + ganhou + " vezes!");
        }
    }

    public static void resposta() {
        exercicio8();
    }

}
