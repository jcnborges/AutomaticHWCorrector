package excercicios;

import java.util.Scanner;

public class Exercicio6 {

    private static StringBuilder obterInformacoes() {
        final StringBuilder sb = new StringBuilder();
        
        try (Scanner ler = new Scanner(System.in)) {
            
            System.out.println("Qual seu nome?");
            final String nome = ler.nextLine();
            
            System.out.println("Quantos anos você tem?");
            final int idade = ler.nextInt();
            
            ler.nextLine();
            
            System.out.println("Qual seu telefone?");
            final String telefone = ler.nextLine();
            
            System.out.println("Qual seu endereço?");
            final String endereco = ler.nextLine();
            
            sb.append("Seu nome é ").append(nome).append(", você tem ").append(idade).append(" anos, mora na rua ").append(endereco).append(" e seu telefone é ").append(telefone).append("\n");
            
        } catch (Exception e) {
            System.err.println("Erro ao obter informações: " + e.getMessage());
        }

        return sb;
    }

    public static void resposta() {
        System.out.println(obterInformacoes());
    }

}
