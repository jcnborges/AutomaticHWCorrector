package excercicios;

public class Exercicio4 {

    private static String calcularValor(double lado1, double lado2, double lado3) {

        if (lado1 == lado2 && lado1 == lado3) {
            return "O triângulo é equilátero";
        } else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3) {
            return "O triângulo é isósceles";
        } else {
            return "O triângulo é escaleno";
        }
    }

    public static void resposta(double lado1, double lado2, double lado3) {
        System.out.println(calcularValor(lado1, lado2, lado3));
    }

}
