package excercicios;

public class Exercicio2 {

    private static StringBuilder calcularValor() {

        final StringBuilder sb = new StringBuilder();
      
        for (int i = 1; i <= 9 ;i++) {
            sb.append("Tabuada do ").append(i).append("\n");
            for(int j = 1; j <= 9; j++) {
                
                sb.append(i).append(" * ").append(j).append(" = ").append(i * j).append("\n\n");
            }
            
        }
        
        return sb;
    }

    public static void resposta() {

        System.out.println(calcularValor());
    }

    
}
