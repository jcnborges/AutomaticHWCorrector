import java.util.Scanner;

public class Exercicio1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Digite um valor em metros: ");
        double metros = scanner.nextDouble();
        
        double decimetros = metros * 10;
        double centimetros = metros * 100;
        double milimetros = metros * 1000;
        
        System.out.println("Valor em decímetros: " + decimetros);
        System.out.println("Valor em centímetros: " + centimetros);
        System.out.println("Valor em milímetros: " + milimetros);
        
        scanner.close();
    }
}