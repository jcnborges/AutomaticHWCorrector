import java.util.Scanner;

public class Exercicio6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Pedindo informações ao usuário
        System.out.print("Digite seu nome: ");
        String nome = scanner.nextLine();
        
        System.out.print("Digite seu endereço: ");
        String endereco = scanner.nextLine();
        
        System.out.print("Digite seu telefone: ");
        String telefone = scanner.nextLine();
        
        System.out.print("Digite sua idade: ");
        int idade = scanner.nextInt();
        
        // Montando a frase com as informações fornecidas
        String frase = "Seu nome é " + nome + ", você tem " + idade + " anos, mora na rua " + endereco + " e seu telefone é " + telefone + ".";
        
        // Exibindo a frase
        System.out.println(frase);
        
        scanner.close();
    }
}