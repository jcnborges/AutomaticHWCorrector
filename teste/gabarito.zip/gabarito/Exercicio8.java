import java.util.Random;
import java.util.Scanner;

public class Exercicio8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        
        int rodada = 1;
        
        System.out.println("Bem-vindo ao jogo de dois dados!");
        System.out.println("Você está jogando contra o computador.");
        System.out.println("Você e o computador vão lançar dois dados em cada rodada.");
        System.out.println("Você avança as rodadas se a soma dos seus dados for maior que a do computador.");
        
        int somaJogador, somaComputador;
        
        do {
            System.out.println("\nRodada " + rodada + ":");
            
            // Jogada do jogador
            System.out.println("Sua vez de jogar. Pressione ENTER para lançar seus dados.");
            scanner.nextLine(); // Espera o jogador pressionar ENTER
            int dado1Jogador = random.nextInt(6) + 1;
            int dado2Jogador = random.nextInt(6) + 1;
            somaJogador = dado1Jogador + dado2Jogador;
            System.out.println("Você lançou " + dado1Jogador + " e " + dado2Jogador + ". Soma: " + somaJogador);
            
            // Jogada do computador
            System.out.println("Vez do computador. Pressione ENTER para o computador lançar seus dados.");
            scanner.nextLine(); // Espera o jogador pressionar ENTER
            int dado1Computador = random.nextInt(6) + 1;
            int dado2Computador = random.nextInt(6) + 1;
            somaComputador = dado1Computador + dado2Computador;
            System.out.println("O computador lançou " + dado1Computador + " e " + dado2Computador + ". Soma: " + somaComputador);
            
            // Determinando o vencedor da rodada
            if (somaJogador > somaComputador) {                
                System.out.println("Você ganhou a rodada!");
            } else {                
                System.out.println("O computador ganhou a rodada.");
            }
                        
            rodada++;
        } while (somaJogador > somaComputador);
        
        scanner.close();
    }
}
