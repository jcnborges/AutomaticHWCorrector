public class Exercicio2 {
    public static void main(String[] args) {
        // Loop para percorrer de 1 a 9
        for (int i = 1; i <= 9; i++) {
            System.out.println("Tabuada do " + i + ":");
            
            // Loop para imprimir a tabuada do número atual
            for (int j = 1; j <= 10; j++) {
                System.out.println(i + " x " + j + " = " + (i * j));
            }
            
            System.out.println(); // Adiciona uma linha em branco entre as tabuadas
        }
    }
}