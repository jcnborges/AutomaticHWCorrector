import java.util.Scanner;

public class Exercicio3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Criando um vetor para armazenar os números
        double[] numeros = new double[10];
        
        // Lendo os números e armazenando no vetor
        for (int i = 0; i < 10; i++) {
            System.out.print("Digite o número " + (i + 1) + ": ");
            numeros[i] = scanner.nextDouble();
        }
        
        // Calculando a média dos números
        double soma = 0;
        for (double numero : numeros) {
            soma += numero;
        }
        double media = soma / numeros.length;
        
        // Encontrando o maior e o menor número
        double maior = numeros[0];
        double menor = numeros[0];
        for (double numero : numeros) {
            if (numero > maior) {
                maior = numero;
            }
            if (numero < menor) {
                menor = numero;
            }
        }
        
        // Exibindo os resultados
        System.out.println("Média dos números: " + media);
        System.out.println("Maior número: " + maior);
        System.out.println("Menor número: " + menor);
        
        scanner.close();
    }
}
