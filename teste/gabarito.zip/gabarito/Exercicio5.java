import java.util.Random;
import java.util.Scanner;

public class Exercicio5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        
        // Sorteando um número aleatório entre 1 e 100
        int numeroSorteado = random.nextInt(100) + 1;
        
        System.out.println("Bem-vindo ao jogo de adivinhação!");
        System.out.println("Tente adivinhar o número entre 1 e 100.");
        
        int tentativas = 0;
        int palpite;
        
        do {
            System.out.print("Digite o seu palpite: ");
            palpite = scanner.nextInt();
            tentativas++;
            
            if (palpite > numeroSorteado) {
                System.out.println("O número sorteado é menor.");
            } else if (palpite < numeroSorteado) {
                System.out.println("O número sorteado é maior.");
            } else {
                System.out.println("Parabéns! Você acertou o número em " + tentativas + " tentativas.");
            }
        } while (palpite != numeroSorteado);
        
        scanner.close();
    }
}
