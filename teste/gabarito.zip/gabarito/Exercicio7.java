import java.util.Random;
import java.util.Scanner;

public class Exercicio7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        
        int pontuacaoUsuario = 0;
        int pontuacaoComputador = 0;
        
        System.out.println("Bem-vindo ao jogo de Jóquei Pow!");
        System.out.println("Você está jogando contra o computador.");
        System.out.println("Você e o computador vão jogar melhor de três.");
        System.out.println("Escolha pedra, papel ou tesoura digitando '1' para pedra, '2' para papel ou '3' para tesoura.");
        
        for (int rodada = 1; rodada <= 3; rodada++) {
            System.out.println("\nRodada " + rodada + ":");
            System.out.print("Escolha sua jogada (1 - Pedra, 2 - Papel, 3 - Tesoura): ");
            int jogadaUsuario = scanner.nextInt();
            
            // Gerando a jogada do computador
            int jogadaComputador = random.nextInt(3) + 1;
            
            // Mostrando as jogadas
            String jogadaUsuarioString = converterJogada(jogadaUsuario);
            String jogadaComputadorString = converterJogada(jogadaComputador);
            System.out.println("Sua jogada: " + jogadaUsuarioString);
            System.out.println("Jogada do computador: " + jogadaComputadorString);
            
            // Determinando o vencedor da rodada
            if ((jogadaUsuario == 1 && jogadaComputador == 3) ||
                (jogadaUsuario == 2 && jogadaComputador == 1) ||
                (jogadaUsuario == 3 && jogadaComputador == 2)) {
                System.out.println("Você ganhou esta rodada!");
                pontuacaoUsuario++;
            } else if (jogadaUsuario == jogadaComputador) {
                System.out.println("Esta rodada empatou!");
            } else {
                System.out.println("O computador ganhou esta rodada.");
                pontuacaoComputador++;
            }
        }
        
        // Determinando o vencedor do jogo
        if (pontuacaoUsuario > pontuacaoComputador) {
            System.out.println("\nParabéns! Você ganhou o jogo!");
        } else if (pontuacaoUsuario < pontuacaoComputador) {
            System.out.println("\nO computador ganhou o jogo. Melhor sorte da próxima vez!");
        } else {
            System.out.println("\nO jogo terminou em empate.");
        }
        
        scanner.close();
    }
    
    // Método para converter o número da jogada em uma string representando a escolha do jogador
    private static String converterJogada(int jogada) {
        switch (jogada) {
            case 1:
                return "Pedra";
            case 2:
                return "Papel";
            case 3:
                return "Tesoura";
            default:
                return "Escolha inválida";
        }
    }
}
